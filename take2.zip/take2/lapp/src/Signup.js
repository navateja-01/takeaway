import React from "react";
import { Link } from "react-router-dom";
import axios from 'axios';
//  import {FormControl, FormGroup, ControlLabel, Checkbox,Form, Col, Button} from 'react-bootstrap'
class Signup extends React.Component {
    constructor(){
        super();
        this.state={
        fs:"",
          email:"",
          password:""

        }
    }
    handleChange =(e)=>{
        e.preventDefault();
        switch(e.target.name){
            case "fs":this.setState({fs:e.target.value});
            break;
        case "email": this.setState({ email: e.target.value });
        break;
      case "pwd": this.setState({ password: e.target.value });
        break;
        }
    }
    handlesubmit = (e)=>{
        e.preventDefault();
        const user = {
            fs:this.state.fs,
            email:this.state.email,
            password:this.state.password
            
        }
    
    axios.post("http://localhost:4200/userSchema/add",user).then(res => console.log(res.data));
      this.setState({
          fs:'',
        email: '',
        password: '',  
      })
    }
    render() {
        
        return (
            <div>
           <form onSubmit={this.handlesubmit}>
           <div className="form-group">
                 <label for="fs">Username</label>
                 <input type="text" class="form-control" id="fs" name="fs" onChange={this.handleChange} value={this.state.fs}/>
             </div>
           <div className="form-group">  
              <label for="email">email</label>
              <input type="email" class="form-control" id="email" name="email" onChange={this.handleChange} value={this.state.email}/> 
               </div> 
             <div className="form-group">
                 <label for="pwd">Password</label>
                 <input type="password" class="form-control" id="pwd" name="pwd" onChange={this.handleChange} value={this.state.password}/>
             </div>
             <div>
                 <input type="submit" value="submit" />
             </div>
           </form>
            <ul>
                <li>
                    <Link to="/">Home</Link>
                    <Link to="/Signin">Signin</Link>
                </li>
            </ul>
            </div>
        );
    }
}
export default Signup;