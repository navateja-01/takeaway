import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Home from "./home";
import Signin from "./Signin";
import Signup from "./Signup";

const Router = () => (
  <BrowserRouter>
    <Switch>
      <Route exact path="/" component={Home} />
      <Route path="/Signin" component={Signin} />
      <Route path="/Signup" component={Signup} />
      
    </Switch>
  </BrowserRouter>
);

export default Router;