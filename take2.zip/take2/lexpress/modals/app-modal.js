var mongoose =  require("mongoose");

var  UserSchema = mongoose.Schema({
    fs:{type:String},
    email:{type:String,required:true},
    password:{type:String}},
    

    {

     collection:'users'
  
});

module.exports = mongoose.model("UserSchema",UserSchema);
