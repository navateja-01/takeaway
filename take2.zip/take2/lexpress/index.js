// var http = require("http");
// var mongoose=require("mongoose");
// //var {requestHandler} = require("./request")

// mongoose.connect("mongodb://127.0.0.1:27017/Appdb",{useNewUrlParser:true});

    

// server.listen(5000,(err)=>{
//     if(err)
//     {
//         console.log("Couldnot start server");
//         return;
//     }
//     console.log("Server started in port 5000");
// })
